let myjokes =  [
          {
              "category": "Programming",
              "type": "single",
              "joke": "Your mama's so FAT she can't save files bigger than 4GB.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": true
              },
              "id": 9,
              "safe": false,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "Eight bytes walk into a bar.\nThe bartender asks, \"Can I get you anything?\"\n\"Yeah,\" reply the bytes.\n\"Make us a double.\"",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 34,
              "safe": true,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "A byte walks into a bar looking miserable.\nThe bartender asks it: \"What's wrong buddy?\"\n\"Parity error.\" it replies. \n\"Ah that makes sense, I thought you looked a bit off.\"",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 24,
              "safe": true,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "ASCII silly question, get a silly ANSI.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 25,
              "safe": true,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "Being a self-taught developer is almost the same as being a cut neck chicken because you have no sense of direction in the beginning.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 184,
              "safe": false,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "// This line doesn't actually do anything, but the code stops working when I delete it.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 12,
              "safe": true,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "The generation of random numbers is too important to be left to chance.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 39,
              "safe": true,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "A programmer puts two glasses on his bedside table before going to sleep.\nA full one, in case he gets thirsty, and an empty one, in case he doesn't.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 3,
              "safe": true,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "Have a great weekend!\nI hope your code behaves the same on Monday as it did on Friday.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": false
              },
              "id": 44,
              "safe": true,
              "lang": "en"
          },
          {
              "category": "Programming",
              "type": "single",
              "joke": "Your momma is so fat, you need to switch to NTFS to store a picture of her.",
              "flags": {
                  "nsfw": false,
                  "religious": false,
                  "political": false,
                  "racist": false,
                  "sexist": false,
                  "explicit": true
              },
              "id": 55,
              "safe": false,
              "lang": "en"
          }
  
      ]
let index = Math.floor(Math.random()*(myjokes.length-1))

console.log(index)
joke.innerHTML = myjokes[index].joke
  